This is a script that will parse the specified folder.
The script takes one argument when it is run - this is the name of the folder in which it will sort.
As a result of the work you get:
    List of files in each category (music, video, photo, etc.)
    A list of all extensions known to the script that are found in the target folder.
    List of all extensions that are unknown to the script.
    All files and folders are renamed
    Empty folders are deleted
    Files with a known format are sorted.
    Files with unknown extensions remain unchanged.